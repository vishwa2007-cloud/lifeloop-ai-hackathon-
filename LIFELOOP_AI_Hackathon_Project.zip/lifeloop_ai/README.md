# LIFELOOP AI — Hackathon Prototype

A polished single-file interactive web prototype for reimagining everyday objects and waste into practical second-life solutions.

## Run it
1. Extract the ZIP.
2. Open `index.html` in Chrome/Edge (no server or installation required).
3. Try the quick demo item buttons, or upload an image.
4. Click **Analyze & reimagine** to see sample/demo suggestions.
5. Choose a solution and mark it completed to grow your Impact Planet and dashboard counters.

## Prototype scope
- Responsive dashboard
- Image upload and preview
- Quick sample scenarios (plastic bottle, cardboard box, old T-shirt, food scraps, glass jar)
- Three suggestions per sample: easiest, low-cost, creative
- Step-by-step action list
- Impact points, history and virtual planet progression
- Browser localStorage saves progress

## Important
This version is a frontend prototype. Uploaded photos are previewed locally; the app does not actually call a vision/AI API yet. Sample analyses are presented in demo mode. Avoid presenting the demo outputs as real AI image recognition.
